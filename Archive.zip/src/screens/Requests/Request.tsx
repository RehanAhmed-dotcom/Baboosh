import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import {requestList} from '../../lib/api';
import Icon1 from 'react-native-vector-icons/EvilIcons';
import Icon from 'react-native-vector-icons/AntDesign';
import {useDispatch, useSelector} from 'react-redux';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {logoutuser, notificationAlert} from '../../redux/actions';
import {ScrollView} from 'react-native-gesture-handler';
const Request = ({navigation}) => {
  const {top, bottom} = useSafeAreaInsets();
  const initial = 0;
  const dispatch = useDispatch();
  const [requests, setRequests] = useState([]);
  const {user, notificationSymbol} = useSelector(({USER, NOTIFICATION}) => ({
    notificationSymbol: NOTIFICATION.notificationSymbol,
    user: USER.userData,
  }));
  useEffect(() => {
    requestList({Auth: user.userdata.api_token}).then(res => {
      setRequests(res.projectdata);
    });
  }, []);
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: 'white',
        paddingTop: Platform.OS === 'ios' ? top : 0,
      }}>
      <View
        style={{
          height: 56,
          backgroundColor: 'white',
          //   elevation: 3,
          borderBottomColor: '#ccc',
          borderBottomWidth: 1,
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 15,
        }}>
        <View style={{width: 35}}>
          <Icon name="arrowleft" size={20} onPress={navigation.goBack} />
        </View>
        <View>
          <Text
            style={{
              // marginLeft: 20,
              fontFamily: 'Boiling-BlackDemo',
              fontSize: 18,
              //   fontWeight: 'bold',
            }}>
            Baboosh{' '}
          </Text>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <TouchableOpacity style={{flexDirection: 'row'}}>
            <Icon1
              name={'bell'}
              style={{marginRight: 10}}
              size={20}
              color="black"
              onPress={() => {
                notificationAlert(false)(dispatch);
                navigation.navigate('Notification');
              }}
            />
            {notificationSymbol ? (
              <Text
                style={{
                  bottom: 12,
                  right: 16,
                  fontWeight: 'bold',
                  color: 'red',
                }}>
                .
              </Text>
            ) : null}
          </TouchableOpacity>
          <Image
            resizeMode="contain"
            source={require('../../images/Question.png')}
            style={{height: 15, width: 15}}
          />
        </View>
      </View>
      <View
        style={{
          marginHorizontal: 15,
          paddingVertical: 30,
          borderBottomWidth: 1,
          borderBottomColor: '#ccc',
        }}>
        <Text
          style={{
            fontSize: 22,
            fontFamily: 'Boiling-BlackDemo',
            paddingBottom: 30,
          }}>
          My Requests
        </Text>
      </View>
      <View style={{flex: 1}}>
        <ScrollView>
          {requests.map((item, index) => (
            <View
              key={index + 'a'}
              style={{
                borderBottomColor: '#ccc',
                borderBottomWidth: 1,
                padding: 15,
              }}>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('ReqDetails', {
                    image: item.image,
                    brand: item.brand,
                    item: item.item,
                    info: item.info,
                    size: item.size,
                  })
                }
                style={{flexDirection: 'row', alignItems: 'center'}}>
                <Image
                  source={{uri: item.image}}
                  style={{width: 50, height: 50, borderRadius: 25}}
                />
                <View style={{marginLeft: 15}}>
                  <Text
                    style={{fontSize: 14, fontFamily: 'HelveticaNeue-Regular'}}>
                    {item.brand}
                  </Text>
                  <Text
                    style={{fontSize: 14, fontFamily: 'HelveticaNeue-Regular'}}>
                    {item.item}
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </View>
    </View>
  );
};
export default Request;
