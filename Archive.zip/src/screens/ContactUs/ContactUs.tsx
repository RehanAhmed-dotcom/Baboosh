import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  Modal,
  ScrollView,Platform
} from 'react-native';
import {messageApi} from '../../lib/api';
import Icon from 'react-native-vector-icons/EvilIcons';
import Icon1 from 'react-native-vector-icons/AntDesign';
import {useSelector} from 'react-redux';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
const ContactUs = ({navigation}) => {
  const [message, setMessage] = useState('');
  const {top, bottom} = useSafeAreaInsets();
  const [vis, setVis] = useState(false);
  const myModal = () => {
    return (
      <Modal
        animationType="slide"
        transparent={true}
        visible={vis}
        onRequestClose={() => {
          setVis(!vis);
        }}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#00000088',
          }}>
          <View
            style={{
              borderRadius: 10,
              padding: 20,
              height: hp(20),
              backgroundColor: 'white',
              width: wp(90),
            }}>
            <View style={{flex: 1}}>
              <Text style={{fontFamily: 'HelveticaNeue-Regular', fontSize: 16}}>
                Message Sent
              </Text>
            </View>
            <View
              style={{
                justifyContent: 'space-between',
                flexDirection: 'row',

                // backgroundColor: 'blue',
              }}>
              <Text></Text>
              <TouchableOpacity
                style={{
                  height: 30,
                  width: 30,
                  alignItems: 'center',
                  justifyContent: 'center',
                  // backgroundColor: 'red',
                }}
                onPress={() => setVis(!vis)}>
                <Text
                  style={{fontSize: 14, fontFamily: 'HelveticaNeue-Regular'}}>
                  Ok
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    );
  };
  const {user} = useSelector(({USER}) => ({
    user: USER.userData,
  }));
  return (
    <View style={{flex: 1, backgroundColor: 'white',paddingTop: Platform.OS === 'ios' ? top : 0,}}>
      <View
        style={{
          height: 56,
          backgroundColor: 'white',
          //   elevation: 3,
          borderBottomColor: '#ccc',
          borderBottomWidth: 1,
          justifyContent: 'space-between',
          flexDirection: 'row',
          alignItems: 'center',
          paddingHorizontal: 15,
        }}>
        <View style={{width: 35}}>
          <Icon1
            name="arrowleft"
            size={20}
            onPress={() => navigation.goBack()}
          />
        </View>
        <View>
          <Text
            style={{
              // marginLeft: 20,
              fontFamily: 'Boiling-BlackDemo',
              fontSize: 18,
              //   fontWeight: 'bold',
            }}>
            Baboosh
          </Text>
        </View>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <Icon
            name={'bell'}
            style={{right: 10}}
            size={20}
            color="black"
            onPress={() => navigation.navigate('Notification')}
          />
          <Image
            resizeMode="contain"
            source={require('../../images/Question.png')}
            style={{height: 15, width: 15}}
          />
        </View>
      </View>
      <View
        style={{
          marginHorizontal: 15,
          paddingVertical: 30,
          borderBottomWidth: 1,
          borderBottomColor: '#ccc',
        }}>
        <Text
          style={{
            fontSize: 22,
            fontFamily: 'Boiling-BlackDemo',
            paddingBottom: 30,
          }}>
          Contact Us
        </Text>
        <Text style={{fontSize: 14, fontFamily:
                  Platform.OS === 'ios'
                    ? 'helveticaneue-thin'
                    : 'HelveticaNeue-Regular',}}>
          Contact Us and our team will contact you soon
        </Text>
      </View>
      <View style={{flex: 1, alignItems: 'center'}}>
        <View
          style={{
            height: hp(50),
            width: wp(90),
            backgroundColor: 'white',
            elevation: 3,
            marginTop: 20,
            borderRadius: 10,
            alignItems: 'center',
          }}>
          <Text
            style={{
              marginTop: 20,
              fontSize: 14,
              fontFamily:
              Platform.OS === 'ios'
                ? 'helveticaneue-thin'
                : 'HelveticaNeue-Regular',
            }}>
            {' '}
            Message Us
          </Text>
          <View
            style={{
              width: '90%',
              marginTop: 20,
              borderWidth: 1,
              borderRadius: 10,
              borderColor: '#ccc',
              height: hp(20),
            }}>
            <TextInput
              placeholder="Message here..."
              placeholderTextColor={'#ccc'}
              multiline
              numberOfLines={5}
              value={message}
              onChangeText={mess => setMessage(mess)}
              style={{
                textAlignVertical: 'top',
                paddingLeft: 10,
                fontSize: 14,
                fontFamily: 'HelveticaNeue-Medium',
                flex: 1,
              }}
            />
          </View>
          <TouchableOpacity
            onPress={() => {
              messageApi({Auth: user.userdata.api_token, message}).then(res => {
                console.log('clg', res);
                if (res) {
                  setVis(!vis);
                  setMessage('');
                } else {
                  Alert.alert('Something went Wrong');
                }
              });
            }}
            style={{
              width: '90%',
              backgroundColor: 'black',
              borderRadius: 30,
              height: 50,
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: hp(5),
            }}>
            <Text
              style={{
                color: 'white',
                fontSize: 14,
                fontFamily:
                Platform.OS === 'ios'
                  ? 'helveticaneue-thin'
                  : 'HelveticaNeue-Regular',
              }}>
              Send
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      {myModal()}
    </View>
  );
};
export default ContactUs;
